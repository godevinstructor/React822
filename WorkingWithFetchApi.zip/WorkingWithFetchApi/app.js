// function getProducts() { 
//     fetch("https://fakestoreapi.com/products" , {
//         method : "GET"
//     })
//     .then(response => response.json()) // Return Body (Contain Data)
//     .then(body => console.log(body))
//     .catch(err => console.log(err))
// }

async function getProducts() { 
    const response = await fetch("https://fakestoreapi.com/products")
    const body = await response.json()
    console.log(body)
}

getProducts()


// function sum(num1 , num2) { 
//     return new Promise((resolve , reject) => { 
//         if(typeof num1 == "number" && 
//             typeof num2 == "number") { 
//             resolve(num1 + num2)
//         }else { 
//             reject("Please Enter Valid Numbers")
//         }
//     })
// }
// // Eventual Completion Or Failure
// sum(10 , 2)
// .then(result => result + 11)
// .then(result => result + 8)
// .then(result => console.log(result)) // 31
// .catch(err => console.log(err))

