// Get Products
async function getProducts() {
    const res = await fetch("https://fakestoreapi.com/products")
    const body = await res.json()
    return body
}

// Render Products
async function renderProducts() { 
    const products = await getProducts()
    const row = document.querySelector(".row")

    for(let product of products) { 
        const div = document.createElement("div")
        div.className = "col-lg-4 col-md-6 col-sm-12 my-2"
        div.innerHTML = `
            <div class="card" style="width: 18rem;">
                <img src="${product.image}" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">${product.title}</h5>
                    <div class="alert alert-info p-2">
                        Product Price <strong>${product.price} $</strong>
                        <br>
                        Product Rate <strong>${product.rating.rate}</strong>
                    </div>
                    <p class="card-text">${product.description}</p>
                    <hr>
                    <a href="https://fakestoreapi.com/" target="_blank"
                    class="btn btn-primary">Go To Source</a>
                </div>
            </div>
        `
        row.appendChild(div)
    }
}

document.addEventListener("DOMContentLoaded" , renderProducts)